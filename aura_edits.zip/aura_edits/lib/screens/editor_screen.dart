import 'package:flutter/material.dart';
import 'tools/cut_tool.dart';
import 'tools/text_tool.dart';
import 'tools/audio_tool.dart';
import 'tools/filter_tool.dart';
import 'tools/speed_tool.dart';
import 'tools/transition_tool.dart';
import 'tools/sticker_tool.dart';
import 'tools/crop_tool.dart';
import 'tools/voiceover_tool.dart';

class EditorScreen extends StatelessWidget {
  const EditorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text('Aura Editor', style: TextStyle(fontSize: 16)),
        actions: [
          TextButton(onPressed: () {}, child: const Text('Export', style: TextStyle(color: Colors.purpleAccent)))
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.black,
              child: const Center(child: Icon(Icons.play_circle_fill, color: Colors.white54, size: 80)),
            ),
          ),
          Container(
            height: 80,
            color: const Color(0xFF1E1E1E),
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _toolButton(context, Icons.content_cut, 'Cut', const CutTool()),
                _toolButton(context, Icons.text_fields, 'Text', const TextTool()),
                _toolButton(context, Icons.music_note, 'Audio', const AudioTool()),
                _toolButton(context, Icons.filter_vintage, 'Filters', const FilterTool()),
                _toolButton(context, Icons.speed, 'Speed', const SpeedTool()),
                _toolButton(context, Icons.compare_arrows, 'Transitions', const TransitionTool()),
                _toolButton(context, Icons.emoji_emotions, 'Stickers', const StickerTool()),
                _toolButton(context, Icons.crop, 'Crop', const CropTool()),
                _toolButton(context, Icons.mic, 'Voiceover', const VoiceoverTool()),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              color: const Color(0xFF121212),
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.all(10),
                children: [
                  Container(width: 100, color: Colors.purpleAccent.withOpacity(0.5), margin: const EdgeInsets.only(right: 5)),
                  Container(width: 80, color: Colors.blueAccent.withOpacity(0.5), margin: const EdgeInsets.only(right: 5)),
                  Container(width: 120, color: Colors.orangeAccent.withOpacity(0.5)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _toolButton(BuildContext context, IconData icon, String title, Widget screen) {
    return InkWell(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 28),
            const SizedBox(height: 5),
            Text(title, style: const TextStyle(fontSize: 10, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}
