import 'package:flutter/material.dart';

class ExportTool extends StatelessWidget {
  const ExportTool({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(title: Text('Export Tool'), backgroundColor: const Color(0xFF1E1E1E)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.build_circle, size: 80, color: Colors.purpleAccent),
            const SizedBox(height: 20),
            Text('Export Interface', style: const TextStyle(fontSize: 24, color: Colors.white)),
            const SizedBox(height: 10),
            const Text('Settings will appear here...', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
